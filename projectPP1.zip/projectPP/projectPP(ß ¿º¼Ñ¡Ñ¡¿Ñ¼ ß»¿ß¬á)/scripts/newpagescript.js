function goToMain() {
    window.location.href = "index.html";
}

const urlParams = new URLSearchParams(window.location.search);
const category = urlParams.get("category");

const categories = {
    vegetables: { icon: "image/Овощи 1.jpg" },
    drinks: { icon: "image/Напитки 3.jpg" },
    plumbing: { icon: "image/Сантехника 1.jpg" },
    fastfood: { icon: "image/Фастфуд 1.jpg" },
    Personal_hygiene: { icon: "image/Личная гигиена 1.jpg" },
    furniture: { icon: "image/Мебель 2.jpg" },
    techniques: { icon: "image/Техника 1.jpg" },
    medicine: { icon: "image/Медицина 1.jpg" },
};

// Проверяем, существует ли категория
if (!categories[category]) {
    alert("Категория не найдена!");
    goToMain();
}

// Устанавливаем иконку категории
const categoryIcon = document.getElementById("category-icon");
if (categoryIcon) {
    categoryIcon.src = categories[category].icon;
} else {
    console.error("Элемент с id='category-icon' не найден.");
}

// Инициализируем список сохранённых товаров
let savedItems = JSON.parse(localStorage.getItem(category)) || [];

const itemList = document.getElementById("item-list");
if (!itemList) {
    console.error("Элемент с id='item-list' не найден.");
}

// Отображаем список товаров
function renderItems() {
    if (!itemList) return;

    itemList.innerHTML = "";

    savedItems.forEach((item, index) => {
        const li = document.createElement("li");
        li.className = "item";

        // Если товар куплен, зачеркнем его
        const itemStyle = item.purchased ? "text-decoration: line-through; color: gray;" : "";

        li.innerHTML = `
            <span style="${itemStyle}">${item.name} (Количество: ${item.quantity})</span>
            <label>
                <input type="checkbox" onclick="togglePurchased(${index})" ${item.purchased ? "checked" : ""}> Куплено
            </label>
            <button onclick="deleteItem(${index})">Удалить</button>
        `;

        itemList.appendChild(li);
    });
}

// Функция для добавления товара
function addItem() {
    const itemNameInput = document.getElementById("item-name");
    const itemQuantityInput = document.getElementById("item-quantity");

    const itemName = itemNameInput.value.trim();
    const itemQuantity = parseInt(itemQuantityInput.value, 10);

    if (!itemName) {
        alert("Введите название товара!");
        return;
    }

    if (!itemQuantity || itemQuantity <= 0) {
        alert("Введите корректное количество товара!");
        return;
    }

    const newItem = {
        name: itemName,
        quantity: itemQuantity,
        purchased: false, // Новый товар изначально не куплен
    };

    savedItems.push(newItem);

    localStorage.setItem(category, JSON.stringify(savedItems));

    renderItems();

    itemNameInput.value = "";
    itemQuantityInput.value = "";
}


function updateList(items) {
    fetch(`http://localhost:3000/api/shopping-list/${listId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
    })
        .then(response => response.json())
        .then(data => console.log("Список обновлён:", data))
        .catch(error => console.error("Ошибка обновления списка:", error));
}


// Функция для удаления товара
function deleteItem(index) {
    savedItems.splice(index, 1);
    localStorage.setItem(category, JSON.stringify(savedItems));
    renderItems();
}

// Функция для переключения состояния купленности
function togglePurchased(index) {
    savedItems[index].purchased = !savedItems[index].purchased;
    localStorage.setItem(category, JSON.stringify(savedItems));
    renderItems();
}

// Функция для удаления всего списка
function clearAllItems() {
    // Подтверждение удаления
    if (!confirm("Вы уверены, что хотите удалить весь список?")) {
        return;
    }

    // Очищаем массив и localStorage
    savedItems = [];
    localStorage.removeItem(category);

    // Перерисовываем пустой список
    renderItems();
}

// Изначальное отображение
renderItems();


const listId = urlParams.get("id"); // Получаем ID из URL

if (listId) {
    fetch(`http://localhost:3000/api/shopping-list/${listId}`)
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Список не найден!') {
                alert(data.message);
                window.location.href = '/';
            } else {
                renderItems(data.items); // Отобразить товары на странице
            }
        })
        .catch(error => console.error("Ошибка загрузки списка:", error));
}


const socket = new WebSocket('ws://localhost:8080');

socket.onopen = () => {
    console.log('Подключение к WebSocket серверу установлено');
    socket.send(JSON.stringify({ message: 'Клиент подключился' }));
};


socket.onmessage = (event) => {
  const updatedItems = JSON.parse(event.data);
  savedItems = updatedItems;  // Обновляем локальные данные
  renderItems();  // Перерисовываем список товаров
};


// При получении данных обновляем список
socket.onmessage = event => {
    const updatedItems = JSON.parse(event.data);
    renderItems(updatedItems); // Функция для обновления отображения товаров
};

// Отправка данных на сервер
function notifyChange(updatedItems) {
    socket.send(JSON.stringify(updatedItems));
}

// Обработка ошибок
socket.onerror = (error) => {
    console.error('Ошибка WebSocket:', error);
};

// Закрытие соединения
socket.onclose = () => {
    console.log('Подключение закрыто');
};


function deleteList() {
    fetch(`http://localhost:3000/api/shopping-list/${listId}`, {
        method: 'DELETE',
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            window.location.href = '/';
        })
        .catch(error => console.error("Ошибка удаления списка:", error));
}

// Инициализируем список товаров, используя localStorage
let savedItems = JSON.parse(localStorage.getItem('shoppingList')) || [];

// Отображаем товары
function renderItems() {
  const itemList = document.getElementById('item-list');
  itemList.innerHTML = '';
  savedItems.forEach((item, index) => {
    const li = document.createElement('li');
    li.className = 'item';
    li.innerHTML = `
      <span>${item.name} (Количество: ${item.quantity})</span>
      <button onclick="deleteItem(${index})">Удалить</button>
    `;
    itemList.appendChild(li);
  });
}

// Функция для добавления товара
function addItem() {
  const itemName = document.getElementById('item-name').value.trim();
  const itemQuantity = parseInt(document.getElementById('item-quantity').value, 10);

  if (!itemName || itemQuantity <= 0) {
    alert('Введите корректное название товара и количество!');
    return;
  }

  const newItem = { name: itemName, quantity: itemQuantity };

  savedItems.push(newItem);
  localStorage.setItem('shoppingList', JSON.stringify(savedItems));

  // Отправляем обновления на сервер
  socket.send(JSON.stringify(savedItems));

  renderItems();
}

// Функция для удаления товара
function deleteItem(index) {
  savedItems.splice(index, 1);
  localStorage.setItem('shoppingList', JSON.stringify(savedItems));

  // Отправляем обновления на сервер
  socket.send(JSON.stringify(savedItems));

  renderItems();
}

// Изначальная отрисовка
renderItems();
