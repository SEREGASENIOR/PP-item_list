// Подключаем библиотеки
const express = require('express'); // Для работы с HTTP запросами
const crypto = require('crypto');  // Для генерации уникальных ID
const bodyParser = require('body-parser'); // Для обработки JSON запросов
const WebSocket = require('ws'); // Для работы с WebSocket
const http = require('http');

// Создаем приложение Express
const app = express();
const server = http.createServer(app);
const PORT = 3000; // Порт, на котором будет работать сервер

// Массив для хранения покупательских списков (вместо базы данных)
let shoppingLists = [];

// Настроим middleware для обработки JSON
app.use(bodyParser.json()); // Позволяет серверу принимать и обрабатывать JSON данные

// Создаем сервер WebSocket
const wss = new WebSocket.Server({ server });

// Когда новый клиент подключается к WebSocket серверу
wss.on('connection', ws => {
    console.log('Новое соединение WebSocket');

    // Когда клиент отправляет сообщение
    ws.on('message', message => {
        // Рассылаем сообщение всем подключённым клиентам
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message); // Отправляем сообщение каждому клиенту
            }
        });
    });
});

app.use(express.static('public')); 

// Главная страница
app.get('/', (req, res) => {
    res.send('Сервер работает!'); // Возвращаем сообщение о том, что сервер работает
});

// Пример маршрута API
app.get('/api/example', (req, res) => {
    res.json({ message: 'Пример API маршрута' }); // Пример API для тестирования
});

// Создание нового покупательского списка
app.post('/api/shopping-list', (req, res) => {
    const { name, items } = req.body; // Получаем имя списка и товары

    // Генерируем уникальный ID для списка
    const id = crypto.randomUUID();

    // Создаем новый список
    const newList = { id, name, items: items || [] };
    shoppingLists.push(newList); // Добавляем список в массив

    // Отправляем ответ с ID нового списка
    res.status(201).json({ id, message: 'Список создан!' });

    // Синхронизируем изменения через WebSocket
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ action: 'create', newList }));
        }
    });
});

// Получение покупательского списка по ID
app.get('/api/shopping-list/:id', (req, res) => {
    const listId = req.params.id; // Получаем ID списка из параметров URL

    // Ищем список по ID
    const list = shoppingLists.find(list => list.id === listId);

    if (!list) {
        return res.status(404).json({ message: 'Список не найден!' }); // Если не нашли, возвращаем ошибку
    }

    // Отправляем найденный список
    res.json(list);
});

// Обновление покупательского списка
app.put('/api/shopping-list/:id', (req, res) => {
    const listId = req.params.id; // Получаем ID списка из параметров URL
    const { items } = req.body; // Получаем новые товары

    // Ищем список по ID
    const list = shoppingLists.find(list => list.id === listId);

    if (!list) {
        return res.status(404).json({ message: 'Список не найден!' }); // Если не нашли, возвращаем ошибку
    }

    // Обновляем список
    list.items = items;

    // Отправляем ответ
    res.json({ message: 'Список обновлён!', list });

    // Синхронизируем изменения через WebSocket
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ action: 'update', list }));
        }
    });
});

// Удаление покупательского списка
app.delete('/api/shopping-list/:id', (req, res) => {
    const listId = req.params.id; // Получаем ID списка из параметров URL

    const index = shoppingLists.findIndex(list => list.id === listId);

    if (index === -1) {
        return res.status(404).json({ message: 'Список не найден!' }); // Если не нашли, возвращаем ошибку
    }

    // Удаляем список
    shoppingLists.splice(index, 1);

    // Отправляем ответ
    res.json({ message: 'Список удалён!' });

    // Синхронизируем изменения через WebSocket
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ action: 'delete', listId }));
        }
    });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`); // Сообщаем, что сервер работает
});
